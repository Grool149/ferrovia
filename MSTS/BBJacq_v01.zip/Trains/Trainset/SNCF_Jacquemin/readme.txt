
	       BB Jacquemin SNCF v0.1
______________________________________________________
!! English informations in the second part of the doc.
______________________________________________________

Contenu:

La version 0.1 du pack BB Jacquemin SNCF contient
deux locomotives en version b�ta. La BB 9223
est pr�sent�e en livr�e verte d'origine.
La BB 9266 arbore la plaque du c�l�bre TEE Mistral.

Nota: Le pack v0.1 contient une cabine provisoire
d�riv�e de l'Acela.
       ________________________________________

Installation:

D�compresser les fichiers dans le r�pertoire de
Train Simulator en respectant l'arborescence des
fichiers.

Le son livr� par d�faut et celui de la HHL
L'installation est compl�t�e par le pack son pour
Jacquemin de Belph�gor:

http://belph80001.free.fr
       ________________________________________

Caract�ristiques techniques des BB 9200

Constructeur : MTE Jeumont Schneider.
Source d'�nergie : Cat�naire aliment�e par des
sous-stations �lectriques.
Tension : 1,5 kV Continu
Puissance en r�gime continu : 4 x 950 kW = 3800kW
Traction : 4 moteurs continus
Vitesse maximum autoris�e : 160 km/h
       ________________________________________

A para�tre:

Les prochaines versions comprendront de nouvelles
livr�es pour la 9200 dont la Capitole. Ainsi que
des 9300, 9700, 16000, 16100, 25100, 25150 et 25200.

En chantier �galement, une cabine des premi�res s�ries
de locomotives � cerclo ancien, flaman et frein H7A
La cabine � cerclo moderne et frein �lectrique PBL2
est �galement en construction par Estelle Pichodou.
       ________________________________________

Cr�dits:

	Vincent Thill "Vix": Mod�lisation 3D
	Olivier Grognet "Groquik": Adaptation � MSTS, textures
	Nicolas Desrues "Belph�gor": Sons

Remerciements sp�ciaux:

	Th�o Alary
	Ben Deville
	Flo Barallon
	Estelle Pichodou
	Chris Longhurst pour sa pr�cieuse FAQ
	Florent Brisou http://perso.wanadoo.fr/florent.brisou/

Retrouvez le meilleur de la simulation ferroviaire Fran�aise sur:

	http://www.simtrain-fr.org

olivier.grognet@gadz.org. � Copyright 2002. Tous droits r�serv�s.
______________________________________________________
ENGLISH SECTION
______________________________________________________

Content:

BB Jacquemin SNCF pack v0.1 contents two
locomotives in beta version. The BB 9223 is in
its green first livery. The BB 9266 is carrying
the plate of the famous TEE Mistral


NB: v0.1 pack contents a temporary modified Acela cab.
       ________________________________________

Installation:

Please unzip all files in Train Simulator directory
respecting extra folders names

Default sounds are HHL ones.
Installation is achieved by Belph�gor's sound pack for
Jacquemin series:

http://belph80001.free.fr
       ________________________________________

BB 9200 series technical datas:

Locomotive builder : MTE Jeumont Schneider.
Power source : Catenary from stationary electric generator.
Voltage : 1.5 kV DC
Continuous power rating: 4 x 950 kW = 3800kW
Traction : 4 moteurs continus
Authorized max. speed: 160 km/h (~ 100 mph)
       ________________________________________

Work in progress:

Next versions will content new liveries for 9200
including Capitole livery. And many 9300, 9700,
16000, 16100, 25100, 25150 et 25200.

In work also, a cab of first locomotives series
with old throttle wheel, flaman and H7A brake.
A cab with modern throttle wheel and electric brake PBL2
is already in construction by Estelle Pichodou.
       ________________________________________

Credits:

	Vincent Thill "Vix": 3D modeling
	Olivier Grognet "Groquik": MSTS Adaptation, animation, eng file, Maps
	Nicolas Desrues "Belph�gor": Sounds

Special Thanks:

	Th�o Alary
	Ben Deville
	Flo Barallon
	Estelle Pichodou
	Chris Longhurst for his precious FAQ
	Florent Brisou http://perso.wanadoo.fr/florent.brisou/

Best of the French railways simulation is there:

	http://www.simtrain-fr.org

olivier.grognet@gadz.org. � Copyright 2002.

