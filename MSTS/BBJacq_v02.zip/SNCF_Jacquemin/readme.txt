
	       BB Jacquemin SNCF v0.2
______________________________________________________
!! English informations in the second part of the doc.
______________________________________________________

Contenu:

La version 0.2 du pack BB Jacquemin SNCF contient
six locomotives en version b�ta. 
La BB 9223 est pr�sent�e en livr�e verte d'origine.
La BB 9266 arbore la plaque du c�l�bre TEE Mistral.
La BB 16004 est une BB 16000 en version sortie d'usine.
La BB 16020 arbore la plaque de la prestigieuse Fl�che d'Or
La BB 16026 telle lors de l'inauguration de l'�lectrification de la ligne Paris-Strasbourg le 9 juillet 1962.
La BB 16048 avec les persiennes allong�es.

Une cabine d'origine de BB 9200 est fournie

       ________________________________________

Installation:

D�compresser les fichiers dans le r�pertoire de
Train Simulator en respectant l'arborescence des
fichiers.

Le son livr� est le pack son pour
Jacquemin de Belph�gor:

http://belph80001.free.fr
       ________________________________________

Caract�ristiques techniques des BB 9200

Constructeur : MTE Jeumont Schneider.
Source d'�nergie : Cat�naire aliment�e par des
sous-stations �lectriques.
Tension : 1,5 kV Continu
Puissance en r�gime continu : 4 x 950 kW = 3800kW
Traction : 4 moteurs continus
Vitesse maximum autoris�e : 160 km/h
       ________________________________________

Caract�ristiques techniques des BB 16000

Constructeur: Jeumont MTE
Tension d'alimentation: monophas� 25 kV
Cha�ne de traction: Graduateur lin�aire 15 kV, redresseurs ignitrons
Motorisation: 1 moteur 920 V par essieu
Puissance totale: 4130 kW

Longueur: 16,680 m
Masse: 88t
Pantographes: 2 x AM 11
       ________________________________________

Cr�dits:

	Vincent Thill "Vix": Mod�lisation 3D
	Olivier Grognet "Groquik": Adaptation � MSTS, textures
	Nicolas Desrues "Belph�gor": Sons

Remerciements sp�ciaux:

	Th�o Alary
	Ben Deville
	Flo Barallon
	Estelle Pichodou
	Chris Longhurst pour sa pr�cieuse FAQ
	Florent Brisou http://perso.wanadoo.fr/florent.brisou/

olivier.grognet@gadz.org. � Copyright 2011. Tous droits r�serv�s.
______________________________________________________
ENGLISH SECTION
______________________________________________________

Content:

BB Jacquemin SNCF pack v0.2 contents six locomotives in beta version. 
The BB 9223 is in its green first livery. 
The BB 9266 is carrying the plate of the famous TEE Mistral.
The BB 16004 in factory livery.
The BB 16020 with the plate of the prestigious Fl�che d'Or (Golden Arrow).
The BB 16026 for Paris-Strasbourg line electrification inauguration, july 9th 1962.
The BB 16048 with elongated louvers.


NB: v0.2 pack contents a BB 9200 cab.
       ________________________________________

Installation:

Please unzip all files in Train Simulator directory
respecting extra folders names

sounds are Belph�gor's sound pack for
Jacquemin series:

http://belph80001.free.fr
       ________________________________________

BB 9200 series technical datas:

Locomotive builder : MTE Jeumont Schneider.
Power source : Catenary from stationary electric generator.
Voltage : 1.5 kV DC
Continuous power rating: 4 x 950 kW = 3800kW
Traction : 4 DC motors
Authorized max. speed: 160 km/h (~ 100 mph)
       ________________________________________

BB 16000 series technical datas:

Locomotive builder : Jeumont MTE
Voltage : AC 25 kV, 50 Hz
Traction : one DC motor 920 V per axle
Continuous power rating : 4130 kW

Length : 16,680 m
Mass : 88t
Pantographes: 2 x AM 11
       ________________________________________

Credits:

	Vincent Thill "Vix": 3D modeling
	Olivier Grognet "Groquik": MSTS Adaptation, animation, eng file, Maps
	Nicolas Desrues "Belph�gor": Sounds

Special Thanks:

	Th�o Alary
	Ben Deville
	Flo Barallon
	Estelle Pichodou
	Chris Longhurst for his precious FAQ
	Florent Brisou http://perso.wanadoo.fr/florent.brisou/


olivier.grognet@gadz.org. � Copyright 2011.