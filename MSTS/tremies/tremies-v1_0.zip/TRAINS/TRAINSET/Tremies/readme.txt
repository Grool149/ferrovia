__________________________________________________________________
    		     Bulk wagons (Tremies in French)

		            V 1.0 
__________________________________________________________________


INSTALLATION
Please unzip all files in Train Simulator directory
respecting extra folders names

DISCLAIMER

"Tremies" package is diffused as FREEWARE. Money can not be expected in any case in exchange of it,
except support and postage costs.
Any commercial use is prohibited without the express autorization of the author.

Reskinners are requested to keep credit to the author in their creations.

__________________________________________________________________

The pack contains four different liveries:

- Transc�r�ales
- Ermewa
- TMF CITA
- Monfer

Each wagon exists in four versions: With or without rear lights, empty or full loaded.

Ex:

"Tremie Transcereales fin vide"  has lights and weighs 20,45 metric tons
"Tremie Ermewa" hasn't lights and weighs 60 metric tons

__________________________________________________________________

Technical datas: 

weight :
empty: 20,450 metric tons
max weight: 61,9 metric tons

Total length : 14,84 meters
Height : 4,100 meters
Width: 3 meters

Max speed: 100 km/h
__________________________________________________________________
olivier.grognet@gadz.org                                07/12/2002 