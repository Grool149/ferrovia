__________________________________________________________________
    		     SNCF CORAIL A5B5tu VTU 84

		          V 0.32 Beta 
__________________________________________________________________


INFORMATIONS LEGALES

Les voitures Corail sont distribu�es en FREEWARE. En aucun cas, elles ne peuvent �tre c�d�es en �change d'argent
hormis les frais li�s au support de distribution et au transport de ce dernier.
Toute utilisation commerciale est strictement interdite sans l'autorisation de l'auteur.

Il est demand� aux reskinneurs de citer l'auteur dans les notes accompagnant leurs cr�ations.

DISCLAIMER

Corail carriages are diffused as FREEWARE. Money can not be expected in any case in exchange of them,
except support and postage costs.
Any commercial use is prohibited without the express autorization of the author.

Reskinners are requested to keep credit to the author in their creations.

__________________________________________________________________

Les voitures Corail VTU sont des voitures voyageurs � couloir central
Elles repr�sentent aujourd'hui la s�rie la plus importante de la SNCF.

Corail VTU carriages are coach carriages. They represent at this time the most significant
carriages class at SNCF (French railways).



Caract�ristiques: 

Poids/Weight :
48t

Longueur hors tampons/Length : 26,400 m
Hauteur au dessus du rail/Height : 4,050 m
Largeur/Width: 2,825 m
Entraxe des pivots de bogies : 18,306 m
Bogies Y32 / Trucks Y32

Nombre de places / Seats
1e: 28
2e: 44

Vitesse limite / max speed: 160 km/h ou 200 km/h

Constructeur / Manufacturer:
Alsthom
__________________________________________________________
olivier.grognet@gadz.org                        08/05/2002 