__________________________________________________________________
    		     SNCF CORAIL VTU 75,78,80

		              V 0.31 Beta 
__________________________________________________________________


INSTALLATION
D�zipper tous les fichiers dans le r�pertoire Trains/Trainset/SNCF_Corail

INSTALLATION
Unzip all files in the directory Trains/Trainset/SNCF_Corail.



INFORMATIONS LEGALES

Le pack Corail est distribu� en FREEWARE. En aucun cas, il ne peut �tre c�d� en �change d'argent hormis
les frais li�s au support de distribution et au transport de ce dernier.
Toute utilisation commerciale est strictement interdite sans l'autorisation de l'auteur.

Il est demand� aux reskinneurs de citer l'auteur dans les notes accompant leurs cr�ations.

Les textures ont �t� compress�es avec AceComp de Martin Wright (martin@mnwright.freeserve.co.uk  http://fly.to/mwgfx/)

DISCLAIMER

Corail package is diffused as FREEWARE. Money can not be expected in any case in exchange of it,
except support and postage costs.
Any commercial use is prohibited without the express autorization of the author.

Reskinners are requested to keep credit to the author in their creations.

Maps have been zipped with Martin Wright'AceComp (martin@mnwright.freeserve.co.uk  http://fly.to/mwgfx/)

__________________________________________________________

Les voitures Corail VTU sont des voitures voyageurs � couloir central
Elles repr�sentent aujourd'hui la s�rie la plus importante de la SNCF.

Corail VTU carriages are coach carriages. They represent at this time the most significant
carriages class at SNCF (French railways).


CONTENU DU PACK / PACK CONTENTS:

CORAIL              V200                       V160

A10tu         50 87 10-97 100-5      |   50 87 10-77 080-3
B5rtux                               |   50 87 85-77 010-0 NF    "Bar Corail"
B5�tu                                |   50 87 84-77 303-0 NF    "Espace Enfants"
B9�tu                                |   50 87 29-77 200-6 NF    "Si�ges Inclinables"
B11tu         50 87 21-97 707-4 NF   |   50 87 21-74 234-6 F/NF
B11rtu                               |   50 87 21-77 630-2 NF

_______________________________________________________________

CORAIL+             V200                       V160

A10tu         50 87 10-92 111-7      |
A10rtu                               |   
B10tu                                |   
B11tu         50 87 21-92 332-6 F/NF |   
B11rtu                               |

_______________________________________________________________

NOUVELLE CORAIL     V200                       V160

A10tu         50 87 10-92 128-1      |   
A10rtu                               |   
B10tu                                |   
B10rtu                               |
B11tu                                |   
B11rtu                               |   

__________________________________________________________

Caract�ristiques: 

Poids/Weight :
A10tu/rtu: 45t
B10/B11: 47t

Longueur hors tampons : 26,400 m
Hauteur au dessus du rail/Height : 4,050 m
Largeur/Width: 2,825 m
Entraxe des pivots de bogies : 18,306 m
Bogies Y32 / Trucks Y32

Nombre de places / Seats
A10tu/rtu : 60
B5rtux:
B5�tu:
B9�tu:
B10tu/rtu: 80 
B11tu/rtu: 88 

Vitesse limite / max speed: 160 km/h ou 200 km/h

Principaux constructeurs / Main manufacturers:

Caisse / Body : Franco-Belge, Alsthom
Bogies / trucks : Franco-Belge, Francorail-MTE, De Dietrich
Convertisseurs / : Traction CEM Oerlikon, Jeumont-Schneider
__________________________________________________________
olivier.grognet@gadz.org                        02/01/2001 